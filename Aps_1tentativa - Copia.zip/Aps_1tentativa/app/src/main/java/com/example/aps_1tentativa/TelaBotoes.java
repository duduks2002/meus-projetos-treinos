package com.example.aps_1tentativa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TelaBotoes extends AppCompatActivity {

    private Button btn_p1;
    private Button btn_p2;
    private Button btn_p3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_botoes);
        btn_p1 = findViewById(R.id.btn_p1);
        btn_p2 = findViewById(R.id.btn_p2);
        btn_p3 = findViewById(R.id.btn_p3);

        btn_p1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirp1();
            }
        });

        btn_p2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirp2();
            }
        });

        btn_p3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirInicio();
            }
        });

    }

    private void abrirInicio() {
        Intent intent = new Intent(TelaBotoes.this , MainActivity.class);
        startActivity(intent);
        finish();
    }
    private void abrirp1() {
        Intent intent = new Intent(TelaBotoes.this , TelaInfos.class);
        startActivity(intent);
        finish();
    }
    private void abrirp2() {
        Intent intent = new Intent(TelaBotoes.this , pedir_senha.class);
        startActivity(intent);
        finish();
    }
}